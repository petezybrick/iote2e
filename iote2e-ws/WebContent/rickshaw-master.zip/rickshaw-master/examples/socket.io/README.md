# Rickshaw + Socket.io

Just a simple example for Websockets support using Rickshaw + Socket.io

# Usage

```
cd examples/socket.io
npm install
node app.js
```

Then visit `http://localhost:8000` to see your graphs updated every second.
